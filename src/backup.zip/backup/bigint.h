/*
	1024-bit unsigned integer storage by Catid@pacbell.net
*/

#ifndef BIGINT_H
#define BIGINT_H

#include "datatypes.h"

#ifdef __int64
	#define BIGINT_WIDTH 32
	#define BIGINT_BASE unsigned __int32
	#define BIGINT_HOLD unsigned __int64
	#define BIGINT_BITS 32
	#define BIGINT_HIGH 0x80000000
	#define BIGINT_MASK 0xffffffff
#else
	#define BIGINT_WIDTH 64
	#define BIGINT_BASE unsigned short
	#define BIGINT_HOLD unsigned int
	#define BIGINT_BITS 16
	#define BIGINT_HIGH 0x8000
	#define BIGINT_MASK 0xffff
#endif

// numerical in/output base
#define BIGINT_PRINT_BASE 10


class bigint
{
	BIGINT_BASE raw[BIGINT_WIDTH];

	// internal
	void zero();

public:
	// init
	bigint();
	bigint(int i);
	bigint(char *i);
	bigint(bigint &i);

	// assignment
	bigint &operator=(int i);
	bigint &operator=(char *i);
	bigint &operator=(bigint &i);

	// cool stuff
	int getInteger();
	void pow(int p);
	int bitCount();
	String toString();

	// addition
	bigint &operator++();
	bigint operator++(int);
	bigint operator+(bigint &i);
	bigint &operator+=(bigint &i);

	// subtraction
	bigint &operator--();
	bigint operator--(int);
	bigint operator-(bigint &i);
	bigint &operator-=(bigint &i);

	// multiplication
	bigint operator*(bigint &i);
	bigint &operator*=(bigint &i);

	// division
	bigint operator/(bigint &i);
	bigint &operator/=(bigint &i);

	// modulus
	bigint operator%(bigint &i);
	bigint &operator%=(bigint &i);

	// shift
	bigint operator<<(int c);
	bigint &operator<<=(int c);
	bigint operator>>(int c);
	bigint &operator>>=(int c);
	bigint operator<<(bigint &c);
	bigint &operator<<=(bigint &c);
	bigint operator>>(bigint &c);
	bigint &operator>>=(bigint &c);

	// xor
	bigint operator^(bigint &i);
	bigint &operator^=(bigint &i);

	// or
	bigint operator|(bigint &i);
	bigint &operator|=(bigint &i);

	// and
	bigint operator&(bigint &i);
	bigint &operator&=(bigint &i);

	// relational
	bool operator==(bigint &i);
	bool operator!=(bigint &i);
	bool operator>=(bigint &i);
	bool operator<=(bigint &i);
	bool operator>(bigint &i);
	bool operator<(bigint &i);

	// externals
	friend bigint getBigint(char *i, int base);

	friend void Components(bigint &a, bigint b, bigint &q, bigint &r);	// prep: q != {a,b,r}, r != {a,b}

} extern BIGINT_0,
		 BIGINT_1,
		 BIGINT_2,
		 BIGINT_3,
		 BIGINT_5,
		 BIGINT_7,
		 BIGINT_10,
		 BIGINT_11,
		 BIGINT_13;	// some helpful pre-allocated instances

#endif	// BIGINT_H
