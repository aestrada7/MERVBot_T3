#include "prize.h"

#include <string.h>


#include "algorithms.h"
#include "map.h"


//////// Tile synchronization ////////

prizeSystem::prizeSystem()
{
	rlevel = 0;
}

Uint32 prizeSystem::getNumberOfGreens(Uint16 population)
{
	long total = IMULHIDWORD(prizeFactor * population, cosmicPrize);
	total = (total >> 6) + (((Uint32)total) >> 31);
	total = limit(total, 256);

	long created = total - list.total;

	return (created > 0) ? created : 0;
}

void prizeSystem::decayGreens()
{
	_listnode <prize> *parse = list.head;

	while (parse)
	{
		prize *p = parse->item;
		parse = parse->next;

		if (getTime() > p->time)
		{
			map[getLinear(p->x, p->y)] = vieNoTile;
			list.kill(p);
		}
	}
}

prize *prizeSystem::createGreen(Uint16 population)
{
	prize *p = new prize;

	Uint32 stop;
	Uint32 current;

	// Find dimensions of the prize bounding rectangle
	Uint16 distance = population * prizeUpgradeVirtual + prizeMinimumVirtual;
	distance = (Uint16)limit(distance, 1024);

	// Fill prize coordinates
	p->x = (prng.getNextG() % (distance - 2)) + ((1024 - distance) >> 1) + 1;
	p->y = (prng.getNextG() % (distance - 2)) + ((1024 - distance) >> 1) + 1;

	// Fill prize type
	p->type = 0;
	current = 0;
	stop	= prng.getNextG() % prizeWeightTotal;
	BYTE *pw = (BYTE*)&prizeWeights;
	for (int i = 0; i < 28; ++i)
	{
		if (current < stop) break;

		current += (*pw++);
		++p->type;
	}

	// Determine if prize type is negative or not
	if (prng.getNextG() % prizeNegativeFactor == 0)
		p->type = -p->type;

	// Fill alive time
	long time = prizeMaxExist - prizeMinExist;
	Uint16 factor = prng.getNextG();
	if (time) time = factor % time;
	p->time = time + prizeMinExist + getTime();

	return p;
}

void prizeSystem::setSettings(arenaSettings *s, BYTE *m)
{
	map = m;

	// Fill settings cache (validity checked externally)
	prizeFactor = s->PrizeFactor;
	prizeDelay = s->PrizeDelay;
	prizeHideCount = s->PrizeHideCount;
	prizeUpgradeVirtual = s->PrizeUpgradeVirtual;
	prizeMinimumVirtual = s->PrizeMinimumVirtual;
	prizeMaxExist = s->PrizeMaxExist;
	prizeMinExist = s->PrizeMinExist;
	prizeNegativeFactor = s->PrizeNegativeFactor;
	memcpy(&prizeWeights, &s->pw, sizeof(prizeSettings));

	if (prizeFactor == 0)				prizeFactor = 1;
	if (prizeDelay == 0)				prizeDelay = 1;
	if (prizeMinimumVirtual < 2)		prizeMinimumVirtual = 2;
	if (prizeMinExist == prizeMaxExist)	++prizeMaxExist;
	if (prizeNegativeFactor == 0)		prizeNegativeFactor = 1;

	// Compute prize weight total
	prizeWeightTotal = 0;
	BYTE *pw = (BYTE*)&prizeWeights;
	for (int i = 0; i < 28; ++i)
	{
		prizeWeightTotal += (*pw++);
	}

	++rlevel;
}

void prizeSystem::randomize(Uint32 seed, Uint32 time)
{
	prng.seed(seed);

	++rlevel;
	lastTime = time;
}

void prizeSystem::doPrizes(Uint16 population)
{
	if (rlevel < 2)
	{
		return;
	}

	if (getTime() < lastTime)
	{
		return;
	}

	long iterations = (getTime() - lastTime) / prizeDelay;

	if (iterations == 0)
		return;

	lastTime = getTime();

	decayGreens();

	Uint32 count = getNumberOfGreens(population);

	for (int i = 0; i < iterations; ++i)
	{
		for (int j = 0; j < prizeHideCount; ++j)
		{
			prize *p = createGreen(population);

			if (count)
			{
				Uint32 offset = getLinear(p->x, p->y);

				if (map[offset])
				{
					delete p;
					p = NULL;
				}
				else
				{
					map[offset] = ssbPrize;
					--count;

					list.append(p);
				}
			}
			else
			{
				delete p;
				p = NULL;
			}
		}
	}
}

void prizeSystem::killGreen(Uint32 time, Uint16 x, Uint16 y)
{
	_listnode <prize> *parse = list.head;

	while (parse)
	{
		prize *p = parse->item;

		if ((p->x == x) && (p->y == y))
		{
			Uint32 off = getLinear(x, y);

			if (map[off] == ssbPrize)
				map[off] = vieNoTile;

			list.kill(parse);

			return;
		}

		parse = parse->next;
	}
}

void prizeSystem::clearList()
{
	list.clear();
}
