#include "fileio.h"

#include <string.h>

#include "algorithms.h"

#ifdef __ZLIB
#include "zlib.h"
#endif


//////// File Access ////////

fileAccess::fileAccess()
{
	fileHandle = -1;
}

fileAccess::~fileAccess()
{
	close();
}

void fileAccess::close()
{
	if (fileHandle != -1)
		_close(fileHandle);
}

bool fileAccess::eof()
{
	return (_tell(fileHandle) == getLength());
}

bool fileAccess::open(char *fileName, bool readOnly)
{
	close();

	if (readOnly)
		fileHandle = _open(fileName, _O_RDONLY | _O_BINARY, _S_IREAD);
	else
		fileHandle = _open(fileName, _O_CREAT | _O_RDWR | _O_BINARY, _S_IREAD | _S_IWRITE);

	return (fileHandle != -1);
}

Uint32 fileAccess::getLength()
{
	Uint32 position = _tell(fileHandle);
	Uint32 length;

	_lseek(fileHandle, 0, SEEK_END);
	length = _tell(fileHandle);

	seekTo(position);

	return length;
}

char *fileAccess::readStuff(Uint32 offset, Uint32 length)
{
	char *stuff = new char[length];

	seekTo(offset);
	_read(fileHandle, stuff, length);

	return stuff;
}

char fileAccess::readNext()
{
	char next;

	if (_read(fileHandle, &next, 1) == 0)
		return 0;

	return next;
}

char *fileAccess::readLine()
{
	char line[256];
	int x = 0;
	char c;

	while ((c = readNext()) != 0x0a)
	{
		if (c != 0x0d)	// Wintext has 0d0a lineterm
		{
			// It's been on my mind, but never got around to
			// fixing the buffer overflow potential here.
			if (x == 254) break;

			line[x++] = c;
		}
	}

	char *msg = new char[x + 1];
	memcpy(msg, line, x);
	msg[x] = '\0';

	return msg;
}

void fileAccess::seekTo(Uint32 offset)
{
	_lseek(fileHandle, offset, SEEK_SET);
}

void fileAccess::writeStuff(void *buffer, Uint32 len)
{
	_write(fileHandle, buffer, len);
}

void fileAccess::setFile(void * buffer, Uint32 len)
{
	_write(fileHandle, buffer, len);
	_chsize(fileHandle, len);
}

#ifdef __ZLIB

bool fileAccess::decompress(void *buffer, Uint32 len)
{
	if (len == 0) return false;

	BYTE  *res	  = NULL;
	Uint32 length = len << 1,
		   status = 0;

	do
	{
		if (res)
			delete []res;

		length += len;
		res = new BYTE[length];

		status = uncompress(res, &length, (BYTE*)buffer, len);
	} while (status == Z_BUF_ERROR);

	if (status) return false;

	writeStuff(res, length);
	_chsize(fileHandle, length);

	return true;
}

#endif
