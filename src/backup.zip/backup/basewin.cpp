#include "basewin.h"

#include <winuser.h>

#include "math.h"

MDIParent GUI;


//////// Window procedures ////////

TextLine::TextLine()
{
	src_color = 0;
	msg_color = 0;
}

void TextLine::set_src(char *psrc_text, int psrc_color)
{
	int len = STRLEN(psrc_text);
	if (len > 31) len = 31;
	MEMCPY(psrc_text, src_text, len + 1);
	src_text[31] = '\0';
	src_len = len;

	src_color = psrc_color;
}

void TextLine::set_msg(char *pmsg_text, int pmsg_color)
{
	int len = STRLEN(pmsg_text);
	if (len > 255) len = 255;
	MEMCPY(pmsg_text, msg_text, len + 1);
	msg_text[255] = '\0';
	msg_len = len;

	msg_color = pmsg_color;
}


//////// Window procedures ////////

ScrollingText::ScrollingText(const ScrollingText &text)
{
	current = text.current;
	total = text.total;

	MEMCPY((void*)text.lines, lines, sizeof(TextLine) * MAX_LINES);
}

ScrollingText::ScrollingText()
{
	current = 0;
	total = 0;
}

void ScrollingText::addline(char *src_text, int src_color, char *msg_text, int msg_color)
{
	lines[current].set_src(src_text, src_color);
	lines[current].set_msg(msg_text, msg_color);

	current = (current + 1) % MAX_LINES;
	if (total < MAX_LINES) ++total;
}

void ScrollingText::addline(char *msg_text, int msg_color)
{
	lines[current].set_msg(msg_text, msg_color);

	current = (current + 1) % MAX_LINES;
	if (total < MAX_LINES) ++total;
}

void DrawLine(HDC dc, int &y, TextLine &text)
{
	RECT rect;
	rect.left = 0;
	rect.top = y;

	SetBkColor(dc, 0);

	if (text.src_color)
	{
		SetTextColor(dc, text.src_color);

		DrawText(dc, text.src_text, text.src_len, &rect, DT_CALCRECT);
		DrawText(dc, text.src_text, text.src_len, &rect, DT_NOCLIP);

		rect.left = rect.right;

		DrawText(dc, "> ", 2, &rect, DT_CALCRECT);
		DrawText(dc, "> ", 2, &rect, DT_NOCLIP);

		rect.left = rect.right;
	}

	SetTextColor(dc, text.msg_color);

	DrawText(dc, text.msg_text, text.msg_len, &rect, DT_CALCRECT);
	DrawText(dc, text.msg_text, text.msg_len, &rect, DT_NOCLIP);

	y = (y << 1) - rect.bottom;
}

void ScrollingText::render(HWND hwnd)
{
	HDC hdc;
	RECT r;

	hdc = GetDC(hwnd);

	DrawText(hdc, "CALCRECT", 2, &r, DT_CALCRECT);

	int i = current,
		lim = total,
		y = r.bottom - r.top;

	GetClientRect(hwnd, &r);

	FillRect(hdc, &r, (HBRUSH)GetStockObject(BLACK_BRUSH));

	y = r.bottom - y;

	while (lim--)
	{
		if (i == 0) i = MAX_LINES;
		--i;

		DrawLine(hdc, y, lines[i]);

		if (y < 0) break;
	}

	ReleaseDC(hwnd, hdc);
}


//////// Window procedures ////////

LRESULT CALLBACK Frame_WndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	switch(msg)
	{
	case WM_DESTROY:
		{
			PostQuitMessage(0);
		}
		break;

	case WM_SIZE:
		{
			GUI.text.render(GUI.hClient);
		}
		break;

	case WM_PAINT:
		{
			GUI.text.render(GUI.hClient);
		}
		break;

	case WM_CREATE_TEXT:
		{
			*((MDIChild**)wparam) = GUI.create(*((char**)lparam));
		}
		break;

	case WM_UPDATE_TEXT:
		{
			((UpdateText*)wparam)->terminal->text.addline(((UpdateText*)wparam)->message.msg, ((UpdateText*)wparam)->rgb);
			((UpdateText*)wparam)->terminal->text.render(((UpdateText*)wparam)->terminal->hWnd);
			delete ((UpdateText*)wparam);
		}
		break;
	}

	return DefFrameProc(hwnd, GUI.hClient, msg, wparam, lparam);
}

LRESULT CALLBACK Child_WndProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	MDIChild *child;

	switch(msg)
	{
	case WM_DESTROY:
		{
			PostQuitMessage(0);
		}
		break;

	case WM_SIZE:
		{
			child = GUI.find(hwnd);
			if (child) child->text.render(hwnd);
		}
		break;

	case WM_PAINT:
		{
			child = GUI.find(hwnd);
			if (child) child->text.render(hwnd);
		}
		break;
	}

	return DefMDIChildProc(hwnd, msg, wparam, lparam);
}


//////// Basic asynchronous window ////////

HWND doEvents()
{
	MSG msg;
	BOOL err;

	while (err = PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
	{
		if (err == -1) return 0;

		TranslateMessage(&msg);
		DispatchMessage(&msg);

		if (msg.message == WM_QUIT)
		{
			return msg.hwnd;
		}
	}

	return 0;
}


//////// MDI Parent window ////////

void MDIParent::threadMain()
{
	//////// Retrieve thread module handle ////////
	hInstance = GetModuleHandle(NULL);

	//////// Register our window classes ////////
	WNDCLASSEX wc;

	ZeroMemory(&wc, sizeof(wc));
	wc.cbSize			= sizeof(wc);
	wc.hbrBackground	= CreateSolidBrush(COLOR_3DFACE);
	wc.lpfnWndProc		= Frame_WndProc;
	wc.hInstance		= hInstance;
	wc.lpszClassName	= CLASS_FRAME;
	RegisterClassEx(&wc);

	ZeroMemory(&wc, sizeof(wc));
	wc.cbSize			= sizeof(wc);
	wc.style			= CS_NOCLOSE;
	wc.lpfnWndProc		= Child_WndProc;
	wc.hInstance		= hInstance;
	wc.lpszClassName	= CLASS_CHILD;
	RegisterClassEx(&wc);

	//////// Create MDI frame ////////
	hMenu = CreateMenu();

	hFrame = CreateWindowEx(0,					// Extended styles
							CLASS_FRAME,		// Class name
							"Frame",			// Window title
							WS_VISIBLE		|
							WS_CLIPCHILDREN	|
							WS_OVERLAPPEDWINDOW,// Styles
							CW_USEDEFAULT,		// Initial x
							CW_USEDEFAULT,		// Initial y
							CW_USEDEFAULT,		// Initial width
							CW_USEDEFAULT,		// Initial height
							NULL,				// Parent window
							hMenu,				// Menu handle
							hInstance,			// Module handle
							NULL);				// Optional parameters

	//////// Create MDI client ////////
	CLIENTCREATESTRUCT cs;

	cs.hWindowMenu = NULL;
	cs.idFirstChild = 3337;

	hClient = CreateWindowEx(0,					// Extended styles
							 "MDICLIENT",		// Class name
							 "Client",			// Window title
							 WS_VISIBLE		|
							 WS_CHILD		|
							 WS_CLIPCHILDREN|
							 WS_VSCROLL		|
							 WS_HSCROLL,		// Styles
							 CW_USEDEFAULT,		// Initial x
							 CW_USEDEFAULT,		// Initial y
							 CW_USEDEFAULT,		// Initial width
							 CW_USEDEFAULT,		// Initial height
							 hFrame,			// Parent window
							 NULL,				// Menu handle
							 GUI.hInstance,		// Module handle
							 &cs);				// Optional parameters

	text.addline("Global messages go here.", RGB(255, 255, 255));

	//////// Process window messages until WM_QUIT ////////
	for (;;)
	{
		HWND deserter;

		if (deserter = doEvents())
		{
			if (deserter == hFrame)
				break;

			kill(deserter);
		}

		Sleep(10);
	}

	//////// Destroy windows on thread termination ////////
	DestroyWindow(hClient);
	DestroyWindow(hFrame);

	//////// Unregister classes on thread termination ////////
	UnregisterClass(CLASS_FRAME, hInstance);
	UnregisterClass(CLASS_CHILD, hInstance);
}

void MDIParent::remoteCreate(MDIChild *&child, char **title)
{
	SendMessage(hFrame, WM_CREATE_TEXT, (WPARAM)&child, (LPARAM)title);
}

void MDIParent::remoteUpdate(MDIChild *child, char *message, int rgb)
{
	UpdateText *text = new UpdateText(child, message, rgb);

	SendMessage(hFrame, WM_UPDATE_TEXT, (WPARAM)text, 0);
}

void MDIParent::remoteDestroy(MDIChild *child)
{
	if (child) SendMessage(child->hWnd, WM_CLOSE, 0, 0);
}

MDIChild *MDIParent::create(char *title)
{
	MDIChild *child = new MDIChild;

	children.append(child);

	child->init(*this, title);

	return child;
}

MDIChild *MDIParent::find(HWND id)
{
	_listnode<MDIChild> *parse = children.head;

	while (parse)
	{
		MDIChild *item = parse->item;

		if (item->hWnd == id)
		{
			return item;
		}

		parse = parse->next;
	}

	return NULL;
}

bool MDIParent::kill(HWND id)
{
	_listnode<MDIChild> *parse = children.head;

	while (parse)
	{
		MDIChild *item = parse->item;

		if (item->hWnd == id)
		{
			children.kill(parse);

			return true;
		}

		parse = parse->next;
	}

	return false;
}


//////// MDI Child window ////////

MDIChild::MDIChild(const MDIChild &child)
{
	hWnd = child.hWnd;
	text = child.text;
}

MDIChild::MDIChild()
{
}

void MDIChild::init(MDIParent &parent, char *title)
{
	//////// Retrieve MDI parameters ////////
	HINSTANCE hInstance = parent.hInstance;
	hClient = parent.hClient;
	hFrame	= parent.hFrame;

	//////// Fill child creation parameters ////////
	MDICREATESTRUCT cs;
	cs.x		= 0;
	cs.y		= 0;
	cs.cx		= 640;
	cs.cy		= 480;
	cs.szClass	= CLASS_CHILD;
	cs.szTitle	= title;
	cs.hOwner	= hInstance;
	cs.lParam	= NULL;
	cs.style	= 0;

	//////// Create child ////////
	hWnd = (HWND)SendMessage(hClient, WM_MDICREATE, 0, (LPARAM)&cs);
}

MDIChild::~MDIChild()
{
	//////// Destroy child ////////
	SendMessage(hClient, WM_MDIDESTROY, (WPARAM)hWnd, 0);
}


//////// Offscreen surface ////////

OffscreenSurface::OffscreenSurface(HDC hostDC, int w, int h)
{
    width = w;
	height = h;
	hDC = CreateCompatibleDC(hostDC);
	hBMP = CreateCompatibleBitmap(hostDC, w, h);
    SelectObject(hDC, hBMP);
}

OffscreenSurface::~OffscreenSurface()
{
	DeleteObject(hBMP);
}

void OffscreenSurface::blit(HDC dest)
{
	BitBlt(dest, 0, 0, width, height, hDC, 0, 0, SRCCOPY);
}

void OffscreenSurface::blit(HDC dest, int x, int y)
{
	BitBlt(dest, x, y, width, height, hDC, 0, 0, SRCCOPY);
}

void OffscreenSurface::blit(HDC dest, int x, int y, int srcx, int srcy, int w, int h)
{
	BitBlt(dest, x, y, w, h, hDC, srcx, srcy, SRCCOPY);
}

void OffscreenSurface::clear()
{
	RECT rect;
	rect.left = 0;
	rect.top = 0;
	rect.left = width;
	rect.bottom = height;
	FillRect(hDC, &rect, 0);
}

HDC OffscreenSurface::getDC()
{
	return hDC;
}
