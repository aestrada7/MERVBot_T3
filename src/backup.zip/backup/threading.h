/*
	Multithreading made easy by Catid@pacbell.net
*/

#ifndef THREADING_H
#define THREADING_H

#define WIN32_LEAN_AND_MEAN
#include <windows.h>


class Mutex
{
	HANDLE hMutex;

public:
	Mutex();
	~Mutex();

	void Lock();
	void Unlock();
};

class SafeThread : public Mutex
{
	HANDLE hThread;

	friend DWORD WINAPI entryPoint(SafeThread *);

public:
	SafeThread();

	virtual void threadMain();
};

#endif	// THREADING_H
