#include "bigint.h"

#include "math.h"

#define WIN32_LEAN_AND_MEAN
#include <windows.h>	// ZeroMemory

bigint BIGINT_0	= 0;
bigint BIGINT_1	= 1;
bigint BIGINT_2	= 2;
bigint BIGINT_3	= 3;
bigint BIGINT_5	= 5;
bigint BIGINT_7	= 7;
bigint BIGINT_10= 10;
bigint BIGINT_11= 11;
bigint BIGINT_13= 13;


// init
void bigint::zero()
{
	ZeroMemory(raw, BIGINT_WIDTH * sizeof(BIGINT_BASE));
}


bigint::bigint()
{
	zero();
}

bigint::bigint(int i)
{
	zero();
	MEMCPY(&i, raw, 4);
}

bigint::bigint(char *i)
{
	*this = getBigint(i, BIGINT_PRINT_BASE);
}

bigint::bigint(bigint &i)
{
	MEMCPY(i.raw, raw, BIGINT_WIDTH * sizeof(BIGINT_BASE));
}


// assignment
bigint &bigint::operator=(int i)
{
	zero();
	MEMCPY(&i, raw, 4);

	return *this;
}

bigint &bigint::operator=(char *i)
{
	*this = getBigint(i, BIGINT_PRINT_BASE);

	return *this;
}

bigint &bigint::operator=(bigint &i)
{
	MEMCPY(i.raw, raw, BIGINT_WIDTH * sizeof(BIGINT_BASE));

	return *this;
}


// cool stuff
int bigint::getInteger()
{
	int i;
	MEMCPY(raw, &i, 4);
	return i;
}

void bigint::pow(int p)
{
	for (int i = 0; i < p; ++i)
	{
		*this *= *this;
	}
}

int bigint::bitCount()
{
	int bits = 0;

	for (int i = BIGINT_WIDTH - 1; i >= 0; --i)
	{
		BIGINT_BASE b = raw[i];

		if (b)
		{
			for (unsigned int x = BIGINT_HIGH; x > 0; x >>= 1)
			{
				if (b & x) return BIGINT_WIDTH * (sizeof(BIGINT_BASE) << 3) - bits;

				++bits;
			}
		}
		else
		{
			bits += sizeof(BIGINT_BASE) << 3;
		}
	}

	return 0;
}

// addition
bigint &bigint::operator++()
{	// pre
	for (int byte = 0; byte < BIGINT_WIDTH; ++byte)
	{
		BIGINT_BASE b = raw[byte];

		++b;

		raw[byte] = b;

		if (b != 0) break;
	}

	return *this;
}

bigint bigint::operator++(int u)
{	// post
	bigint i;
	i = *this;

	for (int byte = 0; byte < BIGINT_WIDTH; ++byte)
	{
		BIGINT_BASE b = raw[byte];

		++b;

		raw[byte] = b;

		if (b != 0) break;
	}

	return i;
}

bigint bigint::operator+(bigint &i)
{
	bigint o;
	o = *this;

	o += i;

	return o;
}

bigint &bigint::operator+=(bigint &i)
{
	BIGINT_HOLD carry = 0;

	for (int byte = 0; byte < BIGINT_WIDTH; ++byte)
	{
		BIGINT_HOLD b = raw[byte], g = i.raw[byte];

		b += g;

		b += carry;

		carry = b >> BIGINT_BITS;

		raw[byte] = (BIGINT_BASE)b;
	}

	return *this;
}


// subtraction
bigint &bigint::operator--()
{	// pre
	for (int byte = 0; byte < BIGINT_WIDTH; ++byte)
	{
		BIGINT_BASE b = raw[byte];

		--b;

		raw[byte] = b;

		if (b != BIGINT_MASK) break;
	}

	return *this;
}

bigint bigint::operator--(int u)
{	// post
	bigint i;
	i = *this;

	for (int byte = 0; byte < BIGINT_WIDTH; ++byte)
	{
		BIGINT_BASE b = raw[byte];

		--b;

		raw[byte] = b;

		if (b != BIGINT_MASK) break;
	}

	return i;
}

bigint bigint::operator-(bigint &i)
{
	bigint o;
	o = *this;

	o -= i;

	return o;
}

bigint &bigint::operator-=(bigint &i)
{
	BIGINT_HOLD carry = 0;

	for (int byte = 0; byte < BIGINT_WIDTH; ++byte)
	{
		BIGINT_HOLD b = raw[byte], g = i.raw[byte];

		b -= g;

		b -= carry;

		carry = (b >> BIGINT_BITS) & 1;

		raw[byte] = (BIGINT_BASE)b;
	}

	return *this;
}


// multiplication
bigint bigint::operator*(bigint &i)
{
	bigint o;
	o = *this;

	o *= i;

	return o;
}

bigint &bigint::operator*=(bigint &in)
{
	bigint c, i;

	c = *this;
	i = in;
	zero();

	do
	{
		if (i.raw[0] & 1)
			*this += c;
		i >>= 1;
		c <<= 1;
	} while (i != BIGINT_0);

	return *this;
}


// division
bigint bigint::operator/(bigint &i)
{
	bigint o;
	o = *this;

	o /= i;

	return o;
}

bigint &bigint::operator/=(bigint &i)
{
	static bigint q, r;

	Components(*this, i, q, r);

	*this = q;

	return q;
}


// modulus
bigint bigint::operator%(bigint &i)
{
	bigint o;
	o = *this;

	o %= i;

	return o;
}

bigint &bigint::operator%=(bigint &i)
{
	static bigint q, r;

	Components(*this, i, q, r);

	*this = r;

	return r;
}


// shift
bigint bigint::operator<<(int c)
{
	bigint o;
	o = *this;

	o <<= c;

	return o;
}

bigint bigint::operator>>(int c)
{
	bigint o;
	o = *this;

	o >>= c;

	return o;
}

bigint &bigint::operator<<=(int c)
{	// strength-reduced
	int lost = c / BIGINT_BITS;
	int shift = c % BIGINT_BITS;

	// bytes to move left
	for (int i = 0; i < lost; ++i)
	{
		for (int x = BIGINT_WIDTH - 1; x > 0; --x)
			raw[x] = raw[x - 1];
		raw[0] = 0;
	}

	// bits to move left
	BIGINT_HOLD carry = 0;

	for (int x = 0; x < BIGINT_WIDTH; ++x)
	{
		BIGINT_HOLD b = raw[x];

		b = (b << shift) | carry;

		raw[x] = (BIGINT_BASE)b;

		carry = b >> BIGINT_BITS;
	}

	return *this;
}

bigint &bigint::operator>>=(int c)
{	// strength-reduced
	int lost = c / BIGINT_BITS;
	int shift = c % BIGINT_BITS;

	// bytes to move right
	for (int i = 0; i < lost; ++i)
	{
		MEMCPY(raw + 1, raw, (BIGINT_WIDTH - 1) * sizeof(BIGINT_BASE));
		raw[BIGINT_WIDTH - 1] = 0;
	}

	// bits to move right
	BIGINT_HOLD carry = 0;

	for (int x = BIGINT_WIDTH - 1; x >= 0; --x)
	{
		BIGINT_HOLD b = raw[x];

		b <<= BIGINT_BITS;

		b = (b >> shift) | carry;

		carry = (b & BIGINT_MASK) << BIGINT_BITS;

		raw[x] = (BIGINT_BASE)(b >> BIGINT_BITS);
	}

	return *this;
}

bigint bigint::operator<<(bigint &c)
{
	int shift;
	MEMCPY(c.raw, &shift, 4);

	return *this << shift;
}

bigint bigint::operator>>(bigint &c)
{
	int shift;
	MEMCPY(c.raw, &shift, 4);

	return *this >> shift;
}

bigint &bigint::operator<<=(bigint &c)
{
	int shift;
	MEMCPY(c.raw, &shift, 4);

	*this <<= shift;

	return *this;
}

bigint &bigint::operator>>=(bigint &c)
{
	int shift;
	MEMCPY(c.raw, &shift, 4);

	*this >>= shift;

	return *this;
}


// xor
bigint bigint::operator^(bigint &i)
{
	bigint o;
	o = *this;

	o ^= i;

	return o;
}

bigint &bigint::operator^=(bigint &i)
{
	for (int byte = 0; byte < BIGINT_WIDTH; ++byte)
	{
		BIGINT_BASE b = raw[byte], g = i.raw[byte];

		b ^= g;

		raw[byte] = b;
	}

	return *this;
}


// or
bigint bigint::operator|(bigint &i)
{
	bigint o;
	o = *this;

	o |= i;

	return o;
}

bigint &bigint::operator|=(bigint &i)
{
	for (int byte = 0; byte < BIGINT_WIDTH; ++byte)
	{
		BIGINT_BASE b = raw[byte], g = i.raw[byte];

		b |= g;

		raw[byte] = b;
	}

	return *this;
}


// and
bigint bigint::operator&(bigint &i)
{
	bigint o;
	o = *this;

	o &= i;

	return o;
}

bigint &bigint::operator&=(bigint &i)
{
	for (int byte = 0; byte < BIGINT_WIDTH; ++byte)
	{
		BIGINT_BASE b = raw[byte], g = i.raw[byte];

		b &= g;

		raw[byte] = b;
	}

	return *this;
}


// relational
bool bigint::operator==(bigint &i)
{
	for (int x = 0; x < BIGINT_WIDTH; ++x)
	{
		if (raw[x] != i.raw[x]) return false;
	}

	return true;
}

bool bigint::operator!=(bigint &i)
{
	for (int x = 0; x < BIGINT_WIDTH; ++x)
	{
		if (raw[x] != i.raw[x])	return true;
	}

	return false;
}

bool bigint::operator>=(bigint &i)
{
	for (int byte = BIGINT_WIDTH - 1; byte >= 0; --byte)
	{
		BIGINT_BASE b = raw[byte], g = i.raw[byte];

		if (b != g)
		{
			return b > g;
		}
	}

	return true;
}

bool bigint::operator<=(bigint &i)
{
	for (int byte = BIGINT_WIDTH - 1; byte >= 0; --byte)
	{
		BIGINT_BASE b = raw[byte], g = i.raw[byte];

		if (b != g)
		{
			return b < g;
		}
	}

	return true;
}

bool bigint::operator>(bigint &i)
{
	for (int byte = BIGINT_WIDTH - 1; byte >= 0; --byte)
	{
		BIGINT_BASE b = raw[byte], g = i.raw[byte];

		if (b != g)
		{
			return b > g;
		}
	}

	return false;
}

bool bigint::operator<(bigint &i)
{
	for (int byte = BIGINT_WIDTH - 1; byte >= 0; --byte)
	{
		BIGINT_BASE b = raw[byte], g = i.raw[byte];

		if (b != g)
		{
			return b < g;
		}
	}

	return false;
}

void recurse_print(String &o, bigint &t)
{	// internal
	bigint q, r, s, base = BIGINT_PRINT_BASE;

	Components(t, base, q, s);
	t = q;

	int i = s.getInteger();

	if (t != BIGINT_0)
		recurse_print(o, t);

	char ch = i;

	if (ch > 9)
		ch += 'a' - 10;
	else
		ch += '0';

	o.append(&ch, 1);
}

String bigint::toString()
{
	String o;
	o.clear();

	recurse_print(o, *this);

	return o;
}

void Components(bigint &a, bigint b, bigint &q, bigint &r)
{
	int shift = 0;

	r = a;
	q.zero();

	if (q == b) return;

	while ((b < r) && ((b.raw[BIGINT_WIDTH - 1] & BIGINT_HIGH) == 0))
	{
		b <<= 1;
		++shift;
	}

	if (b > r)
	{
		b >>= 1;
		--shift;
	}

	for (int i = 0; i <= shift; ++i)
	{
		if (b <= r)
		{
			r -= b;
			b >>= 1;
			q <<= 1;
			q.raw[0] |= 1;
		}
		else
		{
			b >>= 1;
			q <<= 1;
		}
	}
}

bigint getBigint(char *i, int int_base)
{
	bigint r, base, binary;
	r.zero();
	base = int_base;

	char ch;

	while (ch = *i++)
	{
		int bin;

		if (ch >= 'a')	// assumed alpha
			bin = ch - 'a' + 10;
		else			// assumed numerical
			bin = ch - '0';

		binary = bin;

		r *= base;
		r += binary;
	}

	return r;
}
