/*
	MERVBot basic window class by Catid@pacbell.net
*/

#ifndef BASEWIN_H
#define BASEWIN_H

#include "threading.h"
#include "datatypes.h"

#define WIN32_LEAN_AND_MEAN
#include <windows.h>


#define CLASS_FRAME			"Frame3337"
#define CLASS_CHILD			"Child3337"
#define WM_CREATE_TEXT		WM_USER + 1 /* Wparam:(Host::terminal) Lparam:(title) */
#define WM_UPDATE_TEXT		WM_USER + 2 /* Wparam:(Host::terminal) Lparam:(message) */
#define MAX_LINES 512


HWND doEvents();


class OffscreenSurface
{
	friend class ScrollingText;

	int width, height;
	HDC hDC;
	HBITMAP hBMP;

public:
	OffscreenSurface(HDC hostDC, int w, int h);
	~OffscreenSurface();

	void blit(HDC dest);
	void blit(HDC dest, int x, int y);
	void blit(HDC dest, int x, int y, int destx, int desty, int w, int h);

	void clear();

	HDC getDC();
};


struct TextLine
{
	char src_text[32];
	int src_len;
	int src_color;

	char msg_text[256];
	int msg_len;
	int msg_color;

	TextLine();

	void set_src(char *psrc_text, int psrc_color);
	void set_msg(char *pmsg_text, int pmsg_color);
};


class ScrollingText
{
	TextLine lines[MAX_LINES];
	int current, total;

public:
	ScrollingText(const ScrollingText &text);
	ScrollingText();

	void addline(char *src_text, int src_color, char *msg_text, int msg_color);
	void addline(char *msg_text, int msg_color);

	void render(HWND hwnd);
};


class MDIChild
{
public:
	friend class MDIParent;

	void init(MDIParent &parent, char *title);

	HWND hWnd, hFrame, hClient;

	MDIChild(const MDIChild &child);
	MDIChild();
	~MDIChild();

	ScrollingText text;
};


struct UpdateText
{
	MDIChild *terminal;
	int rgb;
	String message;

	UpdateText(MDIChild *t, char *m, int r)
	{
		terminal = t;
		rgb		 = r;
		message  = m;
	}
};


class MDIParent : SafeThread
{
public:
	friend class MDIChild;

	HINSTANCE hInstance;
	HWND hFrame, hClient;
	HMENU hMenu;

	_linkedlist <MDIChild> children;

	void threadMain();

	ScrollingText text;

	MDIChild *create(char *title);
	MDIChild *find(HWND id);
	bool kill(HWND id);

	void remoteCreate(MDIChild *&child, char **title);
	void remoteUpdate(MDIChild *child, char *message, int rgb);
	void remoteDestroy(MDIChild *child);
} extern GUI;

#endif	// BASEWIN_H
