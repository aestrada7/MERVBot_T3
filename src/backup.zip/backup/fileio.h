/*
	File access made easy by Catid@pacbell.net
*/

#ifndef FILEIO_H
#define FILEIO_H

#include <io.h>
#include <fcntl.h>
#include <sys\stat.h>
#include <errno.h>
#include <stdio.h>

#include "datatypes.h"

// Using ZLIB imports?
#define __ZLIB

class fileAccess
{
	int fileHandle;						// File Handle

public:
	fileAccess();						// Initialize to -1
	~fileAccess();						// Close the file

	bool eof();							// End of file?

	bool open(char * fileName,
			  bool readOnly);			// Re-open as a different file

	void close();						// Close the file

	Uint32 getLength();					// Return length without modifying position

	char *readStuff(Uint32 offset,
					Uint32 length);		// Binary read
	char readNext();					// Get next character
	char *readLine();					// Get next line

	void seekTo(Uint32 offset);			// Seek to an offset
	void writeStuff(void *buffer,
					Uint32 len);		// Binary write
	void setFile(void *buffer,
				 Uint32 len);			// Binary write
#ifdef __ZLIB
	bool decompress(void *buffer,
					Uint32 len);		// Uncompress to file
#endif
};

#endif	// FILEIO_H
