#include "threading.h"


//////// Mutex ////////

Mutex::Mutex()
{
	hMutex = CreateMutex(NULL, false, NULL);
}

Mutex::~Mutex()
{
	CloseHandle(hMutex);
}

void Mutex::Lock()
{
	WaitForSingleObject(hMutex, INFINITE);
}

void Mutex::Unlock()
{
	ReleaseMutex(hMutex);
}


//////// Threading ////////

SafeThread::SafeThread()
{
	hThread = CreateThread(NULL, 0, (PTHREAD_START_ROUTINE)entryPoint, this, 0, NULL);
}

void SafeThread::threadMain()
{
}

DWORD WINAPI entryPoint(SafeThread *THIS_THREAD)
{
	THIS_THREAD->threadMain();

	return 0;
}
